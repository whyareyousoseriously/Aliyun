drop table if exists ods_house_developer_info_da;
create table ods_house_developer_info_da
(
     resblock_id bigint comment "楼盘ID"
    ,developer_name string comment "名称,默认值为:''"
    ,developer_is_brand_name string comment "是否品牌名称"
    ,group_name string comment "名称,默认值为:''"
)comment "楼盘对应开发商信息";