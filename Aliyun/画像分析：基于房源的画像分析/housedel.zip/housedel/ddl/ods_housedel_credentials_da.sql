-- 房源证件信息
drop table if exists ods_housedel_credentials_da;
create table if not exists ods_housedel_credentials_da 
(
     id bigint comment "自增ID,默认值为:0" 
    ,housedel_id bigint comment "房源编号,默认值为:0"
    ,credential_type bigint comment "证件类型 1:业主房屋委托书 2：业主身份证 3：房产证 4: 契税证明"
    ,credential_path string comment "证件图片地址"
    ,creator_ucid bigint comment "证件上传人 默认值为0"
    ,auditor_ucid bigint comment "证件审核人 默认值为0"
    ,status bigint comment "0 上传 1 审核通过 2 审核没有通过"
    ,fail_reason string comment "审核失败原因 默认值为''"
    ,create_time string comment "创建时间-开始,默认值为:'1000-01-01 00:00:00'" 
    ,update_time string comment "更新时间-开始,默认值为:'1000-01-01 00:00:00'" 
) comment " 房源证件信息";