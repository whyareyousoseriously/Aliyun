-- 商圈表
drop table if exists ods_house_zoning_bizcircle_da;
create table if not exists ods_house_zoning_bizcircle_da 
(
     id bigint comment "主键"
    ,name string comment "名称,默认值为:''"
    ,circle_keywords string comment "关键字,默认值为:''"
    ,brief string comment "简介,默认值为:''"
    ,full_spell string comment "全拼,默认值为:''"
    ,state bigint comment "状态：0，新建1，有效2，无效,默认值为:0"
    ,city_id bigint comment "城市编号,默认值为:0"
    ,cuser bigint comment "新建人编号,默认值为:0"
    ,ctime string comment "新建时间,默认值为:1000-01-01 00:00:00"
    ,muser bigint comment "修改人编号,默认值为:0"
    ,mtime string comment "修改时间,默认值为:CURRENT_TIMESTAMP"
) comment "商圈表";