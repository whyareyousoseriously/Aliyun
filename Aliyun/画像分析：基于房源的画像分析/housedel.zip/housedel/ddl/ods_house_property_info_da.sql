drop table if exists ods_house_property_info_da;
create table ods_house_property_info_da
(
    resblock_id bigint comment "楼盘ID"
    ,property_office_tel string comment "办公电话,默认值为:''"
    ,property_office_addr string comment "l办公地址,默认值为:''"
    ,property_name string comment "名称,默认值为:''"
    ,property_group_name string comment "名称,默认值为:''"
)comment "楼盘对应物业信息"; ;