-- 房源实勘、审核
drop table if exists ods_housedel_real_prospecting_da;
create table if not exists ods_housedel_real_prospecting_da 
(
      id bigint comment "实勘表主键id"
    ,housedel_id bigint comment "房源委托表主键ID,默认值为:0"
    ,file_type bigint comment "文件类型 1:室 2:厅 3:厨 4:卫"
    ,file_path string comment "实勘照片地址"
    ,broker_ucid bigint comment "实勘人,默认值为:0"
    ,broker_time string comment "成为实勘人时间,默认值为:'1000-01-01 00:00:00'"
    ,audit_ucid bigint comment "审核人ID,默认值为:0"
    ,audit_result bigint comment "审核结果 0：实勘不合格 1：实勘审核通过,默认值为:-1:待审核"
    ,create_time string comment "创建时间,默认值为:'1000-01-01 00:00:00'"
    ,update_time string comment "更新时间,默认值为:'1000-01-01 00:00:00'"
) comment "房源实勘、审核";