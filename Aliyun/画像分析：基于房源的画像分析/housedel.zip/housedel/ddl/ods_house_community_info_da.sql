drop table if exists ods_house_community_info_da;
create table ods_house_community_info_da
(
     resblock_id bigint comment "楼盘ID"
    ,community_info string comment "社区id&(一级社区|二级社区|未知)&名称"
)comment "楼盘对应社区信息";