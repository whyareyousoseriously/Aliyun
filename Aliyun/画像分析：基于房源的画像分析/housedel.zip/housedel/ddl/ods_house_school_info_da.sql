drop table  if exists ods_house_school_info_da;
create table ods_house_school_info_da
(
     building_id bigint comment "楼栋ID"
    ,school_id bigint comment "学校id,默认值为:0"
    ,school_name string comment "名称,默认值为:''"
    ,school_addr string comment "地址,默认值为:''"
    ,school_level_name string comment "学区分级,默认值为:0 1:重点 2：普通 3：其它"
    ,school_property_name string comment "学校性质,默认值为:0 1:私立市重点 2：私立区重点 3：公立市重点 4：公立区重点 5：私立普通 6：公立普通 7：其它"
)comment "楼栋对应学校信息";