drop table if exists ods_house_station_info_da;
create table ods_house_station_info_da
(
     building_id bigint comment "楼栋ID"
     ,station_info string comment "地铁站id&地铁站名称&直线距离&步行距离&步行距离值&步行时间&步行时间值&地铁线ID&地铁线名称"
)comment "楼栋对应地铁站信息";