tunnel upload -fd "\t" E:\用户画像资料\data\t_user.txt   t_user;
tunnel upload -fd "\t" E:\用户画像资料\data\t_user_certification.txt   t_user_certification;
tunnel upload -fd "\t" E:\用户画像资料\data\t_user_education.txt   t_user_education;
tunnel upload -fd "\t" E:\用户画像资料\data\t_user_experience.txt   t_user_experience;
tunnel upload -fd "\t" E:\用户画像资料\data\t_user_intension.txt   t_user_intension;
tunnel upload -fd "\t" E:\用户画像资料\data\t_user_project.txt   t_user_project;
tunnel upload -fd "\t" E:\用户画像资料\data\t_user_skill.txt   t_user_skill;