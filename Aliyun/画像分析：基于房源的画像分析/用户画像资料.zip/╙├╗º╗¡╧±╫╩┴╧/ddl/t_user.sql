-- 用户基础信息 
create table t_user 
(
    id          bigint comment "用户ID"
   ,name        string comment "用户名"
   ,sex         bigint comment "性别 1:男 2:女 0:未知"
   ,birthday    string comment "生日"
   ,card_id     string comment "身份证号"
   ,email       string comment "邮箱"
   ,mobile      string comment "手机号"
   ,hight       double comment "身高"
   ,weight      double comment "体重"
   ,create_time string comment "注册时间"
   ,update_time string comment "更新时间"
);

-- 用户技能信息
create table t_user_skill
(
    id              bigint comment "自增ID"
   ,user_id         bigint comment "用户ID参考t_user.id"
   ,skill_id        bigint comment "技能ID"
   ,skill_name      string comment "技能名称"
   ,level_id        bigint comment "掌握程度"
   ,level_name      string comment "掌握程度名称"
   ,use_months      bigint comment "使用时长单位为月"
   ,create_time     string comment "注册时间"
   ,update_time     string comment "更新时间"
);

-- 用户教育经历
create table t_user_education
(
    id              bigint comment "自增ID"
   ,user_id         bigint comment "用户ID参考t_user.id"
   ,school_id       bigint comment "学校ID"
   ,school_name     string comment "学校名称"
   ,major_id        bigint comment "专业ID"
   ,major_name      string comment "专业名称"
   ,start_time      string comment "开始时间"
   ,end_time        string comment "结束时间"
   ,degree_id       bigint comment "学历：1专科、2本科、3硕士、4博士、5其它"
   ,degree_name     string comment "学历：1专科、2本科、3硕士、4博士、5其它"
   ,create_time     string comment "创建时间"
   ,update_time     string comment "更新时间"
);

-- 用户工作经历
create table t_user_experience
(
    id          bigint comment "自增ID"
   ,user_id     bigint comment "用户ID参考t_user.id"
   ,corp_id     bigint comment "企业ID"
   ,corp_name   string comment "企业名称"
   ,job_id      bigint comment "职位ID"
   ,job_name    string comment "职位名称"
   ,start_time  string comment "开始时间"
   ,end_time    string comment "结束时间"
   ,depart_id   bigint comment "部门ID"
   ,depart_name string comment "部门名称"
   ,employ_cnt  bigint comment "下属人数"
   ,salary      bigint comment "薪水"
   ,create_time string comment "创建时间"
   ,update_time string comment "更新时间"
);

-- 用户项目经历
create table t_user_project
(
    id                     bigint comment "自增ID"
   ,user_id                bigint comment "用户ID参考t_user.id"
   ,experience_id          bigint comment "工作经历ID"
   ,start_time             string comment "开始时间"
   ,end_time               string comment "结束时间"
   ,project_name           string comment "项目名称"
   ,responsibilities_desc  string comment "工作职责描述"
   ,performance_desc        string comment "工作业绩描述"
   ,create_time             string comment "创建时间"
   ,update_time             string comment "更新时间"
);

-- 用户证书
create table t_user_certification
(
    id              bigint comment "自增ID"
   ,user_id         bigint comment "用户ID参考t_user.id"
   ,cert_id         bigint comment "证书ID"
   ,cert_name       string comment "证书名称"
   ,create_time         string comment "创建时间"
   ,update_time         string comment "更新时间"
);

-- 求职意愿
create table t_user_intension
(
    id                  bigint comment "自增ID"
   ,user_id             bigint comment "用户ID参考t_user.id"
   ,industry_id         bigint comment "行业ID"
   ,industry_name       string comment "行业名称"
   ,salary_expectation  bigint comment "期望待遇 万元/年"
   ,job_city            string comment "工作城市"
   ,create_time         string comment "创建时间"
   ,update_time         string comment "更新时间"
);

