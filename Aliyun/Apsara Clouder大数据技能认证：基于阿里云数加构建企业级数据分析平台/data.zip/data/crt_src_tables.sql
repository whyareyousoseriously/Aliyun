﻿create table customers (
  customer_id bigint,
  customer_name varchar(100),
  age int,
  gender int,
  city_id int,
  gen_date date default '2000-01-01'
)
;
create table dim_product(product_id bigint,
  product_name varchar(100),
  price decimal(20,2),
  product_category_id int
)
;
create table orders (order_id bigint,
  customer_id bigint,
  product_id int,
  product_cnt int,
	order_amt decimal(20,2),
	shipping_type_id int,
  order_time datetime
)
;
create table dispatch(
  dispatch_id bigint,
  order_id bigint,
  express_staff_id bigint,
  storehouse_id int,
  expect_time datetime,
  dispatch_time datetime
)
;
create table dilivery(
  dilivery_id bigint,
  dispatch_id bigint,
  dilivery_status_id int,
  update_time datetime
);

create table stock(
  storehouse_id int,
  product_id int,
  product_cnt bigint,
  last_update_time datetime
)
;
create table st_buzi_all_backup (
	buzi_date				date,
	order_cnt				bigint,
	total_amt				dec(20,2),
	new_cust_cnt		bigint,
	curr_cust_cnt		bigint,
	stock_item_cnt	bigint,
	stock_amt				bigint,
	succ_sent_rate	dec(10,4),
	sent_prd_cnt		bigint
)
;



